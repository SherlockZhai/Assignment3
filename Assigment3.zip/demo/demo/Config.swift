//
//  Config.swift
//  demo
//
//  Created by Starry on 2024/5/9.
//

import SwiftUI

enum Config{
    
    static let domain = "http://49.232.213.55"
    
    
}
